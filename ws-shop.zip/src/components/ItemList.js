import Price from './Price'

import {
    Card, CardText, CardBody,
    CardTitle, CardSubtitle, Button
} from 'reactstrap';

const ItemList = (props) => {

    const mappedItems = props.items.map((item) =>
        <div
            className="col-xs-12 col-md-4 d-flex mt-3 mb-2"
            key={item.id}
            style={cardStyles}
        >
            <Card className='w-100'>
                <CardBody>
                    <CardTitle>
                        <h4>
                            {
                                // Handling special characters with regex
                                item.name
                                    .replace(/&amp;/g, '&')
                                    .replace(/&#160;/g, '')
                            }
                        </h4>
                    </CardTitle>

                    {/* 
                    Display main hero image, 
                    pull array of images for carousel

                    If no image object, return a div explaining no image is available, do not display carousel on click
                    if the images are available, then return a new component for the carousel div, passing down the props for the images
                    create component that has carousel
                    */}

                    <CardText>
                        {item.images ? <p>image component</p> : <p>No image component</p>}
                    </CardText>

                    {/* Price component finds which price object is available and returns the price object values found */}
                    <CardSubtitle>
                        <Price product={item} />
                    </ CardSubtitle>

                </CardBody>
                <Button className="btn-sm" href={item.links.www}>Details</Button>
            </Card>
        </div >

    )

    return (
        <div className="container-fluid">
            <div className="row card-deck">{mappedItems}</div>
        </div>
    )
}

const cardStyles = {
    textAlign: 'center',
    justifyContent: 'center',
}

export default ItemList