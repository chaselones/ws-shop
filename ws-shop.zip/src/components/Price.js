//Returns a price depending on which price object was available
const Price = (props) => {
    const checkVal = () => {
        if (props?.product?.price?.regular) {
            return (
                <div>{`$${props.product.price.regular}`}</div>
            )
        } else if (props?.product?.priceRange?.regular) {
            return (
                <div>{`$${props.product.priceRange.regular.low}`} - {`$${props.product.priceRange.regular.high}`}</div>
            )
        } else if (props?.product?.priceRange?.selling) {
            return (
                <div>{`$${props.product.priceRange.selling.low}`} - {`$${props.product.priceRange.selling.high}`}</div>
            )
        } else {
            return null
        }
    }

    return (checkVal())
}

export default Price