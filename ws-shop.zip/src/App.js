import { Component } from 'react'
import ItemList from './components/ItemList'
import './App.css';

export default class App extends Component {

  state = {
    items: []
  }

  componentDidMount() {

    //  Why is the API only being fetched SOMETIMES ?
    fetch("http://www.westelm.com/services/catalog/v4/category/shop/new/all-new/index.json", { mode: 'cors' })
      .then(res => res.json())
      .then(data => {
        this.setState({ items: data.groups })
      })
      .catch(error => console.log(error.message))
  }

  render() {
    return (
      <div className="App">
        {/* <Header></Header> */}
        {this.state.items[0] !== undefined ?
          <ItemList items={this.state.items}></ItemList> :
          <p style={{ textAlign: 'center' }}> {`Loading...`} </p>}
        {/* <Footer></Footer> */}
      </div>
    )
  }
}